import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import Link from "next/link";

export default async function FacultyProfile({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const faculty = await prisma.faculty.findUnique({
    where: { id },
    include: { ratings: true },
  });

  if (!faculty) return notFound();

  const totalReviews = faculty.ratings.length;

  const getAvg = (key: string) => {
    if (totalReviews === 0) return "0";
    const sum = faculty.ratings.reduce(
      (acc: any, r: any) => acc + (r[key] || 0),
      0
    );
    return (sum / totalReviews).toFixed(1);
  };

  return (
    <div className="min-h-screen bg-black text-white p-6 md:p-12">
      <div className="max-w-4xl mx-auto space-y-10">
        <Link href="/" className="text-blue-400 hover:underline">
          ← Back to Directory
        </Link>

        {/* HEADER */}
        <div className="flex flex-col md:flex-row gap-8 items-center bg-gray-900 border border-gray-800 p-8 rounded-3xl">
          
          {/* ✅ FIXED IMAGE */}
          {faculty.photoUrl ? (
            <img
              src={faculty.photoUrl}
              className="w-40 h-40 rounded-2xl object-cover border-4 border-gray-800"
              alt={faculty.name}
            />
          ) : (
            <div className="w-40 h-40 rounded-2xl bg-gray-800 flex items-center justify-center text-2xl font-bold text-gray-400">
              {faculty.name?.charAt(0) || "?"}
            </div>
          )}

          <div className="text-center md:text-left space-y-2">
            <h1 className="text-4xl font-bold">{faculty.name}</h1>
            <p className="text-gray-400 text-lg">{faculty.designation}</p>
            <p className="text-blue-500 font-medium">
              {faculty.department}
            </p>

            <div className="pt-4">
              <Link
                href={`/rate/${faculty.id}`}
                className="bg-white text-black px-8 py-3 rounded-xl font-bold hover:bg-gray-200 transition"
              >
                Rate this Faculty
              </Link>
            </div>
          </div>
        </div>

        {/* STATS */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[
            { label: "Teaching Clarity", score: getAvg("teachingClarity") },
            { label: "Approachability", score: getAvg("approachability") },
            { label: "Grading Fairness", score: getAvg("gradingFairness") },
            { label: "Punctuality", score: getAvg("punctuality") },
            { label: "Non-Partiality", score: getAvg("partiality") },
            { label: "Behaviour", score: getAvg("behaviour") },
          ].map((stat) => (
            <div
              key={stat.label}
              className="bg-gray-900/50 border border-gray-800 p-6 rounded-2xl text-center"
            >
              <p className="text-gray-500 text-sm mb-1">{stat.label}</p>
              <p className="text-3xl font-bold">{stat.score}/5</p>
            </div>
          ))}
        </div>

        {/* REVIEWS */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold">
            Student Feedback ({totalReviews})
          </h2>

          {faculty.ratings.length === 0 ? (
            <p className="text-gray-600 italic">
              No reviews yet. Be the first to add one!
            </p>
          ) : (
            faculty.ratings.map((r) => (
              <div
                key={r.id}
                className="bg-gray-900 border border-gray-800 p-6 rounded-2xl"
              >
                <p className="text-gray-300 leading-relaxed italic">
                  "{r.review || "No written feedback provided."}"
                </p>
                <p className="text-gray-600 text-xs mt-4 uppercase tracking-widest">
                  Anonymous Review •{" "}
                  {new Date(r.createdAt).toLocaleDateString()}
                </p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}