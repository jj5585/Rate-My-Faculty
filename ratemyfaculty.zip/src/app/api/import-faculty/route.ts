import { prisma } from "@/lib/prisma";
import * as cheerio from "cheerio";

export async function POST(req: Request) {
  try {
    const { url } = await req.json();

    if (!url) {
      return Response.json({ error: "URL required" }, { status: 400 });
    }

    // 🧠 Fetch page
    const res = await fetch(url);
    const html = await res.text();
    const $ = cheerio.load(html);

    // 🔍 NAME
    const name = $("h1").first().text().trim();

    // 🔍 DESIGNATION
    const designation =
      $("p")
        .filter((_, el) =>
          $(el).text().toLowerCase().includes("professor")
        )
        .first()
        .text()
        .trim() || "Faculty";

    // 🔥 IMAGE (CSS + IMG fallback)

    let photoUrl: string | null = null;

    // 1️⃣ Try extracting from <style> (SRM trick)
    const styleContent = $("style").html() || "";
    const match = styleContent.match(/url\((.*?)\)/);

    if (match && match[1]) {
      photoUrl = match[1].replace(/['"]/g, "");
    }

    // 2️⃣ Fallback to <img> if CSS fails
    if (!photoUrl) {
      photoUrl =
        $("img")
          .map((_, el) => $(el).attr("src"))
          .get()
          .find((src) => src && src.includes("wp-content")) || null;
    }

    // 🧠 OTHER FIELDS (basic for now)
    const department = "SRM";
    const researchInterest = "";

    // 🧪 DEBUG LOG
    console.log("SCRAPED:", {
      name,
      designation,
      photoUrl,
    });

    // 🔒 UPSERT (prevents duplicates)
    const faculty = await prisma.faculty.upsert({
      where: { profileUrl: url },
      update: {
        name,
        designation,
        department,
        researchInterest,
        photoUrl,
      },
      create: {
        name,
        designation,
        department,
        researchInterest,
        photoUrl,
        profileUrl: url,
      },
    });

    return Response.json({
      success: true,
      facultyId: faculty.id,
    });

  } catch (error) {
    console.error("IMPORT ERROR:", error);
    return Response.json({ error: "Failed to import faculty" }, { status: 500 });
  }
}