import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import * as cheerio from "cheerio"

export async function POST(req: Request) {
  try {
    const { url } = await req.json()

    if (!url || !url.includes("srmist.edu.in")) {
      return NextResponse.json(
        { error: "Invalid SRM faculty URL" },
        { status: 400 }
      )
    }

    // Check if already exists
    const existing = await prisma.faculty.findUnique({
      where: { profileUrl: url },
    })

    if (existing) {
      return NextResponse.json({ facultyId: existing.id })
    }

    // Fetch page
    const res = await fetch(url)
    const html = await res.text()

    const $ = cheerio.load(html)

    // Extract data (based on SRM structure)
    const name = $("h1").first().text().trim()
    const designation = $("h2").first().text().trim()

    let department = ""
    $("p").each((_, el) => {
      const text = $(el).text()
      if (text.toLowerCase().includes("department")) {
        department = text
      }
    })

    const image = $("img").first().attr("src")

    // Save to DB
    const faculty = await prisma.faculty.create({
      data: {
        name,
        designation,
        department,
        photoUrl: image,
        profileUrl: url,
      },
    })

    return NextResponse.json({ facultyId: faculty.id })
  } catch (err) {
    console.error(err)
    return NextResponse.json(
      { error: "Failed to import faculty" },
      { status: 500 }
    )
  }
}