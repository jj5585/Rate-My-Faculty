"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"

export default function ImportPage() {
  const [url, setUrl] = useState("")
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleImport = async () => {
    if (!url) {
      alert("Please enter a URL")
      return
    }

    setLoading(true)

    try {
      const res = await fetch("/api/import-faculty", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ url }),
      })

      const data = await res.json()

      if (data.facultyId) {
        router.push(`/faculty/${data.facultyId}`)
      } else {
        alert("Import failed")
      }
    } catch (err) {
      console.error(err)
      alert("Something went wrong")
    }

    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center">
      <div className="bg-gray-900 p-8 rounded-2xl shadow-lg w-full max-w-lg space-y-6">
        
        <h1 className="text-2xl font-bold text-center">
          Import Faculty
        </h1>

        <input
          type="text"
          placeholder="Paste SRM faculty URL..."
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="w-full p-3 rounded-lg bg-black border border-gray-700 focus:outline-none focus:ring-2 focus:ring-white"
        />

        <button
          onClick={handleImport}
          disabled={loading}
          className="w-full bg-white text-black py-3 rounded-lg font-semibold hover:bg-gray-200 transition"
        >
          {loading ? "Importing..." : "Import Faculty"}
        </button>

      </div>
    </div>
  )
}