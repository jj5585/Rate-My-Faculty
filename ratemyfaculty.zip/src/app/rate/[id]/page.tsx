"use client"

import { useState } from "react";
import { useSession, signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { use } from "react"; // ✅ IMPORTANT

const CRITERIA = [
  { id: "teachingClarity", label: "Teaching Clarity", desc: "How well do they explain concepts?" },
  { id: "approachability", label: "Approachability", desc: "Can you ask doubts without fear?" },
  { id: "gradingFairness", label: "Grading Fairness", desc: "Do they mark answers fairly?" },
  { id: "punctuality", label: "Punctuality", desc: "Do they arrive and leave on time?" },
  { id: "partiality", label: "Not Partial", desc: "5 = Treats everyone equally, 1 = Very partial" },
  { id: "behaviour", label: "General Behaviour", desc: "Attitude towards students in class" },
];

export default function RatePage({ params }: { params: Promise<{ id: string }> }) {
  // ✅ FIX: unwrap params using React.use()
  const { id: facultyId } = use(params);

  const { data: session, status } = useSession();
  const router = useRouter();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [scores, setScores] = useState<Record<string, number>>({
    teachingClarity: 5,
    approachability: 5,
    gradingFairness: 5,
    punctuality: 5,
    partiality: 5,
    behaviour: 5,
  });

  const [review, setReview] = useState("");

  if (status === "loading") {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center text-white">
        Loading...
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black text-white p-6">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold">Sign in to Rate</h1>
          <p className="text-gray-400">
            We use Google Sign-in to ensure 1 review per student.
          </p>
          <button
            onClick={() => signIn("google")}
            className="bg-white text-black px-8 py-3 rounded-xl font-bold"
          >
            Continue with Google
          </button>
        </div>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/ratings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          facultyId,
          ...scores,
          review,
        }),
      });

      const data = await res.json();

      if (!res.ok) throw new Error(data.error || "Failed to submit");

      router.push(`/faculty/${facultyId}`);
      router.refresh();
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-6 pb-20">
      <div className="max-w-2xl mx-auto space-y-8">
        <header>
          <h1 className="text-3xl font-bold">Submit Your Review</h1>
          <p className="text-gray-400 mt-2">
            Your identity is hidden via SHA-256 hashing.
          </p>
        </header>

        {error && (
          <div className="bg-red-500/10 border border-red-500 text-red-500 p-4 rounded-xl">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid gap-6">
            {CRITERIA.map((item) => (
              <div
                key={item.id}
                className="bg-gray-900/50 border border-gray-800 p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div>
                  <h3 className="font-bold text-lg">{item.label}</h3>
                  <p className="text-gray-500 text-sm">{item.desc}</p>
                </div>

                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() =>
                        setScores({ ...scores, [item.id]: num })
                      }
                      className={`w-10 h-10 rounded-lg font-bold transition ${
                        scores[item.id] === num
                          ? "bg-blue-600 text-white"
                          : "bg-gray-800 text-gray-400 hover:bg-gray-700"
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="space-y-2">
            <label className="font-bold text-lg">
              Written Review (Optional)
            </label>
            <textarea
              value={review}
              onChange={(e) => setReview(e.target.value)}
              placeholder="Describe your experience..."
              className="w-full h-32 bg-gray-900 border border-gray-800 rounded-2xl p-4 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <button
            disabled={loading}
            className="w-full bg-white text-black font-bold py-4 rounded-2xl text-lg hover:bg-gray-200 transition disabled:opacity-50"
          >
            {loading ? "Submitting..." : "Post Review"}
          </button>
        </form>
      </div>
    </div>
  );
}